A Pen created at CodePen.io. You can find this one at https://codepen.io/knekk/pen/xXraeE.

 Login page inspired by Google's Material Design - Using clear and intentional animations to interact and entertain the user during typing and login's pending and granted states.